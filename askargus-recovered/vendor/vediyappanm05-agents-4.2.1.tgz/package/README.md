# AskArgus Orchestration Agent

A TypeScript library for LLM agent orchestration — tool calling, multi-agent graphs, message formatting, streaming, and provider abstraction.

## Installation

```bash
npm install @vediyappanm05/agents
```

## Features

- Multi-provider LLM support (OpenAI, Anthropic, Google, AWS Bedrock, Azure, Groq, Mistral, OpenRouter)
- LangGraph-based agent graphs (single + multi-agent)
- Tool calling with MCP integration
- Streaming support with event handling
- Message formatting and context management
- Memory cleanup and garbage collection
- Langfuse tracing integration
- Investigation pipeline for multi-domain queries

## Usage

```typescript
import { Run, StandardGraph } from '@vediyappanm05/agents';

const run = await Run.create({
  graphConfig: {
    type: 'standard',
    model: 'gpt-4',
    tools: [...]
  }
});

const result = await run.processStream(inputs, config);
```

## Documentation

See the `docs/` directory for detailed documentation on:
- Graph types and configuration
- Streaming and events
- Message formatting
- Context management
- Investigation pipeline

## License

UNLICENSED - Private package for internal use only.
